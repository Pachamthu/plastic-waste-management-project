# Plastic Waste Field Study Website

**Student:** Pachamuthu  
**Course:** B.E. CSE (AI & ML)  
**College:** Rathinam Technical Campus  
**Location:** Coimbatore, Tamil Nadu

## GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`, `style.css`, and `script.js`.
3. Go to **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/ (root)`.
5. Save and open the generated website link.

Before submitting, replace the field-visit location and add your real photos/video.
